"""Shipment anomaly analysis package."""
